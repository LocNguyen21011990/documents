/**
 * Created by MyPC on 10/9/2016.
 */
import React, {Component} from 'react';
import  "../css/css1.css";

class App extends Component {
    render() {
        return (
        <div>
            <h1 className="style1">This is React! Thanh Kute</h1>
            <div className="style2"></div>
        </div>
        );
    }
}
export default App;