/**
 * Created by MyPC on 10/9/2016.
 */
import React from 'react';
import ReactDOM from 'react-dom';
import App from './hello';

ReactDOM.render(<App />, document.getElementById("main"));
